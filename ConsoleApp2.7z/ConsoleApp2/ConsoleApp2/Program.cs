﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections;


namespace LINQDemo
{
    class Program
    {
        static void Main(string[] args)
        {
            //int[] number = {01,20,22,56,31,16,17,49 };
            //var res = from n in number//its a reference ITS DECLARATIVE QUERY SYNTAX
            //          where (n % 2 == 0)
            //          select n;


            //SYNTAX USING EXTENSION METHODS(lambda expression)
            //var res = number.Where(n => n % 2 == 0);

            //   Dictionary
            //foreach(var i in res)
            //{
            //    Console.WriteLine(i);
            //}
            //Console.WriteLine("***********************");
            //number[1] = 9;

            //foreach (var i in res)
            //{
            //    Console.WriteLine(i);
            //}

            List<Student> studs = Student.GetAll();
            var res = from s in studs
                      select new { s.RollNo, s.Name };//anonymous object
            foreach (var r in res)
            {
                Console.WriteLine(r.RollNo + ", " + r.Name + "\n");
            }

            //Get all marks from students-1,2,3 4,5,6 7,8,9

            //var res1 = from s in studs
            //           from m in s.Marks
            //           select m;
            //foreach(var m in res1)
            //{
            //    Console.WriteLine(m);
            //}

            //Console.WriteLine("======== Using Extension Methods======");
            ////Using Extension Methods
            //var res2 = studs.SelectMany(s => s.Marks);
            //foreach (var m in res2)
            //{
            //    Console.WriteLine(m);
            //}


            //student list according to names

            //var res3 = from s in studs
            //           orderby s.Name, s.Age
            //           select s;
            //foreach (var item in res3)
            //{
            //    Console.WriteLine(item.Name);
            //}
            //Console.WriteLine("======== Using Extension Methods======");

            //var res4 = studs.OrderBy(s => s.Name);
            //foreach (var item in res4)
            //{
            //    Console.WriteLine(item.RollNo + " , " + item.Name);
            //}

            //var res5 = studs.OrderBy(s => s.Name).ThenBy(s => s.Age);//.Reverse()
            //foreach (var item in res5)
            //{
            //    Console.WriteLine(item.RollNo + " , " + item.Name);
            //}
            var res1 = from s in studs
                       group s by s.Age;
            foreach(var grp in res1)
            {
                Console.WriteLine("Age " +grp.Key+ " Group");
                foreach(var s in grp)
                {
                    Console.WriteLine(s.RollNo + "," + s.Name + "," + s.Age);
                }
            }
            Console.ReadKey();
        }
    }

}
