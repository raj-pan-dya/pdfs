﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace LINQDemo
{
    class Student
    {
        public int RollNo { get; set; }
        public string Name { get; set; }
        public int[] Marks { get; set; }
        public int Age { get; set; }


        public static List<Student> GetAll()
        {
            List<Student> studs = new List<Student>//collection initializer
            {
                new Student{RollNo=101,Age= 19,Name="Rudrendra",Marks=new int[]{45,67,98,89}},//Object Initializer
                new Student{RollNo=102,Age= 22,Name="Raju",Marks=new int[]{46,27,94,99}},
                new Student{RollNo=103,Age= 24,Name="Balam",Marks=new int[]{48,77,95,89}},
                new Student{RollNo=103,Age= 27,Name="Siddhu",Marks=new int[]{48,77,95,89}},
                new Student{RollNo=103,Age= 24,Name="Shareit",Marks=new int[]{48,77,95,89}},
                new Student{RollNo=103,Age= 24,Name="Amit",Marks=new int[]{48,77,95,89}}
            };
            return studs;
        }
    }
}
